import javax.swing.SwingUtilities;

public class main {

	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(() -> {
			TopicModelerGUI TopicModeler = new TopicModelerGUI();
            	gui.setVisible(true);
       	        });
	}
}


        
    
